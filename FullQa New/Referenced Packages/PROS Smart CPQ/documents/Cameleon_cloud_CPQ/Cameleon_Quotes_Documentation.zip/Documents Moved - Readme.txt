﻿The documents of the PROS Smart CPQ Managed Package have been moved to another location.

To view and donwload
  - USER'S GUIDE
  - DEPLOYMENT & CUSTOMIZATION GUIDE

Please log on https://connect.pros.com/products/cameleon-cpq